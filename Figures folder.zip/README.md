# Exercise Library — Animated Stick Figures

CC0 stick-figure exercise thumbnails that **animate the critical portion of each lift** —
a lightweight alternative to 3D or video demos. Built as a single self-contained
animation engine plus a reference-browser UI.

![patterns](uploads/figures/patterns/squat.svg)

## What's here

| Path | What it is |
|------|-----------|
| `figures-engine.js` | The animation engine — defines the `<stick-figure>` web component and all rigs. No dependencies. |
| `Exercise Library.dc.html` | Reference-browser UI (search + filter by movement pattern), shown in three visual directions. |
| `support.js` | Runtime that lets the `.dc.html` file open directly in a browser. |
| `uploads/figures/` | The original static source SVGs (`patterns/` archetypes + `exercises/` overrides). CC0. |

## Using the component

Load the engine, then drop in a tag per exercise:

```html
<script src="figures-engine.js"></script>

<stick-figure ex="goblet-squat"></stick-figure>

<!-- themeable (e.g. for dark backgrounds) -->
<stick-figure ex="pull-up" stroke="#ece9dd" accent="#35c48d" ground="#4a473d"></stick-figure>
```

### Attributes

| Attribute | Default | Notes |
|-----------|---------|-------|
| `ex` | `isolation` | Rig id (see list below). |
| `stroke` | `#2c2c2a` | Figure/limb color. |
| `accent` | `#0f6e56` | Loaded implement (dumbbell / plate / arrow). |
| `ground` | `#cfcdc4` | Floor, bench, box, bar. |
| `speed` | `1` | Playback multiplier. |

The SVG fills its container — size it with CSS (`width`, `aspect-ratio: 1`).

## Rigs

`goblet-squat` · `romanian-deadlift` · `overhead-press` · `db-floor-press` ·
`chest-supported-row` · `single-arm-row` · `reverse-lunge` · `db-step-up` ·
`calf-raise` · `suitcase-carry` · `dead-bug` · `vertical-pull` (pull-up) ·
`isolation` (biceps curl)

Together these cover every movement pattern in the seed set: squat, hinge,
vertical/horizontal push, vertical/horizontal pull, lunge, carry, core, calf, isolation.

## How the animation works

Each rig is described as a set of **named joints**, **bones** (joint pairs drawn as
line segments), a **head**, and **props**. Two-to-four **keyframe poses** capture the
extremes of the rep; the engine interpolates between them with an ease-in-out curve
and loops (ping-pong for most lifts, a walking cycle for carries).

Performance:
- One shared `requestAnimationFrame` loop drives all instances at ~30 fps.
- An `IntersectionObserver` pauses figures that scroll off-screen.
- `prefers-reduced-motion` freezes each figure at a representative pose.

## Adding a new movement

Add an entry to `RIGS` in `figures-engine.js`:

```js
"my-move": {
  pattern: "squat",
  ground: [40, 112, 80, 112],           // floor line, or null
  bones: [["neck","hip"], ["hip","knee"], ["knee","foot"]],
  head: "head",
  props: [{ type: "dumbbell", at: "hand", len: 15 }],
  frames: [ { /* start pose */ }, { /* end pose */ } ],
  mode: "pp",                            // "pp" (ping-pong) or "loop"
  period: 2400                           // ms per cycle
}
```

Coordinates use the source `viewBox 0 0 120 120`. Props: `dumbbell`, `plate`,
`arrow` (attach to a joint via `at`, or place with `x`/`y`).

## License

All figures and rig data are **CC0 / public domain**. Use freely.
